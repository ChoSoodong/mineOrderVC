//
//  JXCategoryTitleVerticalZoomCellModel.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/2/14.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "JXCategoryTitleCellModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JXCategoryTitleVerticalZoomCellModel : JXCategoryTitleCellModel

@property (nonatomic, assign) CGFloat maxVerticalFontScale;

@end

NS_ASSUME_NONNULL_END
