






#import "JXPagerView.h"

#import "JXCategoryTitleView.h"


@interface SDMyOrderController : UIViewController<JXPagerViewDelegate, JXPagerMainTableViewGestureDelegate>

/** 默认选中的索引 */
@property (nonatomic, assign) NSInteger selectedIndex;

@end
