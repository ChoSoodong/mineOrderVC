





#import <UIKit/UIKit.h>
#import "JXPagerView.h"
NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger,SDMyOrderType){
    
    SDMyOrderTypeAll = 0,               //全部订单
    SDMyOrderTypePendingPayment,        //待付款
    SDMyOrderTypeToBeShipped,           //待发货
    SDMyOrderTypeToBeReceived,          //待收货
    SDMyOrderTypeToBeEvaluated          //待评价
};

@interface SDMyOrderSubController : UIViewController <JXPagerViewListViewDelegate>

/** 订单类型 */
@property (nonatomic, assign) SDMyOrderType orderType;

@end

NS_ASSUME_NONNULL_END
