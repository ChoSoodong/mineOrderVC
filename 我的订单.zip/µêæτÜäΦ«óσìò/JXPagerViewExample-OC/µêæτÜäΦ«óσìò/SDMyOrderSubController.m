






#import "SDMyOrderSubController.h"


@interface SDMyOrderSubController ()<UITableViewDataSource, UITableViewDelegate>

/** tableView */
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, copy) void(^scrollCallback)(UIScrollView *scrollView);
@property (nonatomic, strong) NSIndexPath *lastSelectedIndexPath;

@end

@implementation SDMyOrderSubController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
  
    [self.view addSubview:self.tableView];
    
}


#pragma mark - 创建TableView
-(UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        
        _tableView.backgroundColor = [UIColor clearColor];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        //_tableView.contentInset = UIEdgeInsetsMake(<#CGFloat top#>, <#CGFloat left#>, <#CGFloat bottom#>, <#CGFloat right#>);
        _tableView.scrollIndicatorInsets = _tableView.contentInset;
        
        //_tableView.tableHeaderView = <#[[MTHomeHeaderView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 180)]#>;
        
        _tableView.rowHeight = 200;
        
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
//        [_tableView registerClass:[<#MTSectionHeaderView#> class] forHeaderFooterViewReuseIdentifier:<#homeHeaderId#>];
//        [_tableView registerClass:[<#MTHomeTestCell#> class] forCellReuseIdentifier:<#homeTestCellId#>];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
        
        

//        _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//
//
//        }];
        
    }
    return _tableView;
}



#pragma mark - UITableViewDataSource, UITableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 30;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.textLabel.text =@"111";
   
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"%zd",indexPath.section);
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    !self.scrollCallback ?: self.scrollCallback(scrollView);
}

#pragma mark - JXPagingViewListViewDelegate

- (UIView *)listView {
    return self.view;
}

- (UIScrollView *)listScrollView {
    return self.tableView;
}

- (void)listViewDidScrollCallback:(void (^)(UIScrollView *))callback {
    self.scrollCallback = callback;
}

- (void)listDidAppear {
    NSLog(@"ordertype == %zd",self.orderType);
    
    
}

- (void)listDidDisappear {
    NSLog(@"listDidDisappear");
}
@end
